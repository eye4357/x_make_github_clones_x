"""Package facade for local development tooling."""

from x_make_github_clones_x.x_cls_make_github_clones_x import (
    RepoRecord,
    x_cls_make_github_clones_x,
)

__all__ = ["RepoRecord", "x_cls_make_github_clones_x"]
